#include<stdio.h>
int main()
{
int n;
printf("Enter the hex decimal number:-");
scanf("%x",&n);
printf("The decimal value is:%d",n);
return 0;
}
